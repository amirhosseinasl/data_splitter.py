# 🧪 data_splitter.py

A simple and practical utility for splitting datasets into training and testing sets — with support for **deterministic hashing-based splitting** using stable identifiers.

## 📦 Features

- ✅ Random shuffle-based splitting (like `sklearn.model_selection.train_test_split`)
- ✅ Deterministic, stable test/train split based on hashing
- ✅ Ideal for ML pipelines that need reproducibility
- ✅ Utility to create unique identifiers from coordinates (lat/lon)

## 📌 Example

```python
import pandas as pd
from data_splitter import generate_identifier_from_coords, split_train_test_by_id

df = pd.read_csv("your_data.csv")
df = generate_identifier_from_coords(df)
train_set, test_set = split_train_test_by_id(df, test_ratio=0.2, id_column='identifier')
```

## 📄 License

MIT License
