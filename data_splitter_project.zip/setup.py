from setuptools import setup, find_packages

setup(
    name='data_splitter',
    version='0.1.0',
    description='A simple utility for stable train/test data splitting.',
    author='Your Name',
    packages=find_packages(),
    install_requires=['pandas', 'numpy'],
)
