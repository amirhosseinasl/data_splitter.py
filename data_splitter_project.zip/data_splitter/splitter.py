import numpy as np
from zlib import crc32

def shuffle_and_split_df(df, test_ratio=0.2, seed=42):
    """
    Randomly splits a DataFrame into train and test sets.
    """
    np.random.seed(seed)
    shuffled_indices = np.random.permutation(len(df))
    test_set_size = int(len(df) * test_ratio)
    test_indices = shuffled_indices[:test_set_size]
    train_indices = shuffled_indices[test_set_size:]
    return df.iloc[train_indices], df.iloc[test_indices]

def is_identifier_in_test_set(identifier, test_ratio):
    """
    Checks if an identifier belongs to the test set using a hash.
    """
    return crc32(np.int64(identifier)) < test_ratio * 2**32

def split_train_test_by_id(df, test_ratio, id_column):
    """
    Splits DataFrame into train/test sets based on hashed identifiers.
    """
    ids = df[id_column]
    in_test_set = ids.apply(lambda id_: is_identifier_in_test_set(id_, test_ratio))
    return df.loc[~in_test_set], df.loc[in_test_set]

def generate_identifier_from_coords(df, lat_col='latitude', lon_col='longitude', id_col='identifier'):
    """
    Generates a unique identifier from coordinates.
    """
    df[id_col] = (df[lon_col] * 1000).round().astype(int) + df[lat_col].round().astype(int)
    return df
