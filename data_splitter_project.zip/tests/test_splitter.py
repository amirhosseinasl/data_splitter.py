import pandas as pd
from data_splitter import generate_identifier_from_coords, split_train_test_by_id

def test_split_function():
    df = pd.DataFrame({
        'longitude': [10.0, 20.0, 30.0, 40.0],
        'latitude': [50.0, 60.0, 70.0, 80.0]
    })
    df = generate_identifier_from_coords(df)
    train, test = split_train_test_by_id(df, test_ratio=0.5, id_column='identifier')
    assert len(train) + len(test) == len(df)
